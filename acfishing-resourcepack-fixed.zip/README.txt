=== ACFishing 리소스팩 사용법 ===

1. 이 폴더(acfishing-resourcepack) 전체를 .zip으로 압축하세요
2. 서버의 resource_packs 폴더에 넣거나 서버 리소스팩으로 설정하세요
   (server.properties: resource-pack=URL 또는 클라이언트 직접 적용)

텍스처 추가 방법:
  assets/acfishing/textures/item/ 폴더에
  물고기ID.png 파일을 넣으면 자동으로 해당 물고기에 적용됩니다!

CustomModelData 번호표:
물고기ID                     CMD번호      기본재질
--------------------------------------------------
carp                      10001      cod
crucian                   10002      cod
bass                      10003      salmon
trout                     10004      salmon
salmon                    10005      salmon
catfish                   10006      cod
eel                       10007      cod
pike                      10008      salmon
cherry_salmon             10009      salmon
dace                      10010      cod
loach                     10011      cod
mandarin_fish             10012      tropical_fish
snakehead                 10013      cod
rainbow_trout             10014      salmon
sweetfish                 10015      salmon
bluegill                  10016      tropical_fish
fresh_eel                 10017      cod
mudfish                   10018      cod
bitterling                10019      tropical_fish
tigerfish                 10020      tropical_fish
zacco                     10021      cod
freshwater_goby           10022      cod
stone_moroko              10023      cod
dark_chub                 10024      cod
sculpin                   10025      cod
dark_sleeper              10026      cod
freshwater_shrimp         10027      cod
minnow                    10028      cod
chub                      10029      salmon
king_salmonid             10030      salmon
mackerel                  10031      cod
flounder                  10032      cod
red_snapper               10033      tropical_fish
tuna                      10034      salmon
squid                     10035      cod
rockfish                  10036      cod
sea_bass                  10037      salmon
yellowtail                10038      salmon
striped_mullet            10039      cod
black_porgy               10040      tropical_fish
anchovy                   10041      cod
dolphin_fish              10042      tropical_fish
barracuda                 10043      salmon
sea_bream                 10044      tropical_fish
hairtail                  10045      cod
blowfish                  10046      pufferfish
opah                      10047      pufferfish
swordfish                 10048      salmon
cuttlefish                10049      cod
horse_mackerel            10050      cod
halibut                   10051      cod
marlin                    10052      salmon
red_drum                  10053      salmon
sea_catfish               10054      cod
alfonsino                 10055      cod
japanese_jack             10056      salmon
grouper                   10057      tropical_fish
sardine                   10058      cod
herring                   10059      cod
garfish                   10060      cod
triggerfish               10061      tropical_fish
wahoo                     10062      salmon
japanese_seaperch         10063      cod
pond_crucian              10064      cod
largemouth                10065      salmon
golden_carp               10066      tropical_fish
swamp_eel                 10067      cod
koi                       10068      tropical_fish
frog                      10069      cod
mudcarp                   10070      cod
bullfrog                  10071      cod
freshwater_clam           10072      cod
rice_fish                 10073      cod
water_strider             10074      cod
swamp_carp                10075      cod
red_carp                  10076      tropical_fish
giant_snakehead           10077      cod
coelacanth                10078      tropical_fish
golden_trout              10079      salmon
great_white_shark         10080      salmon
oarfish                   10081      cod
arapaima                  10082      salmon
giant_trevally            10083      salmon
giant_squid               10084      cod
platinum_carp             10085      tropical_fish
albino_catfish            10086      cod
napoleon_fish             10087      tropical_fish
ghost_fish                10088      cod
rainbow_fish              10089      tropical_fish
dragon_fish               10090      tropical_fish
dorado                    10091      cod
sturgeon                  10092      salmon
leafy_seadragon           10093      tropical_fish
sunfish                   10094      tropical_fish
moonfish                  10095      tropical_fish
anglerfish                10096      cod
sea_angel                 10097      tropical_fish
